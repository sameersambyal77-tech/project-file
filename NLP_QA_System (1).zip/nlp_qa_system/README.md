# NLP-Based Question Answering System Using Deep Learning

**Name:** Sameer Sambyal  **UID:** 25MCI10011

A Retriever–Reader question answering system. Upload documents (PDF/TXT) or paste text, ask a
question, and the system extracts the exact answer span from your documents with a confidence score.

## Architecture
```
Question ─► Preprocess ─► TF-IDF Retriever (top-K chunks) ─► BERT Reader ─► Best Answer + Confidence + Source
```
| Stage | Technique |
|---|---|
| Preprocessing | whitespace/noise cleaning, tokenization, overlapping chunking |
| Retriever | TF-IDF (unigrams+bigrams, stop-words removed) + cosine similarity |
| Reader | Pretrained BERT-family model fine-tuned on SQuAD (Hugging Face `pipeline`) |
| UI | Streamlit |

## Setup
```bash
python -m venv venv
venv\Scripts\activate        # Windows   (Linux/Mac: source venv/bin/activate)
pip install -r requirements.txt
streamlit run app.py
```
The first run downloads the model (~250 MB for DistilBERT) and needs internet; later runs use the cache.

## Usage
1. Upload files / paste text / tick the sample document.
2. Type a question, click **Get Answer**.
3. See the answer, confidence, highlighted source passage and all candidate answers.

Optional offline check of the retrieval part: `python test_retriever.py`

## Files
- `app.py` – Streamlit interface
- `qa_engine.py` – preprocessing, TF-IDF retriever, BERT reader, QA pipeline
- `sample_docs/sample.txt` – demo knowledge base
- `test_retriever.py` – retrieval test

## Models (selectable in sidebar)
- `distilbert-base-cased-distilled-squad` (default, fast)
- `deepset/roberta-base-squad2` (more accurate)
- `bert-large-uncased-whole-word-masking-finetuned-squad` (largest, slowest)

## Evaluation
Pretrained models are evaluated on SQuAD with Exact Match (EM) and F1. DistilBERT ≈ 79 EM / 86 F1 on SQuAD v1.1.

## Limitations & Future Scope
- Extractive only: the answer must be written in the documents.
- TF-IDF is keyword based; could be replaced by dense retrieval (Sentence-BERT + FAISS).
- Future: multilingual support, generative answers, multi-document citations.
