"""
NLP-Based Question Answering System Using Deep Learning
Run:  streamlit run app.py
"""
import html
import os

import streamlit as st

from qa_engine import (DEFAULT_MODEL, MODEL_OPTIONS, QAReader, QASystem,
                       read_uploaded, tokenize)

st.set_page_config(page_title="NLP Question Answering System", page_icon="💬", layout="wide")

SAMPLE_PATH = os.path.join(os.path.dirname(__file__), "sample_docs", "sample.txt")


@st.cache_resource(show_spinner="Loading BERT model (first time downloads it)...")
def load_reader(model_name: str) -> QAReader:
    return QAReader(model_name)


def highlight(context: str, start: int, end: int) -> str:
    return (html.escape(context[:start])
            + "<mark style='background:#ffd54f;padding:2px 4px;border-radius:4px'>"
            + html.escape(context[start:end]) + "</mark>"
            + html.escape(context[end:]))


# ---------------- Sidebar ----------------
st.sidebar.title("⚙️ Settings")
model_name = st.sidebar.selectbox("Transformer model", MODEL_OPTIONS,
                                  index=MODEL_OPTIONS.index(DEFAULT_MODEL))
top_k = st.sidebar.slider("Top-K chunks (TF-IDF retrieval)", 1, 10, 3)
chunk_size = st.sidebar.slider("Chunk size (words)", 100, 400, 200, step=50)
overlap = st.sidebar.slider("Chunk overlap (words)", 0, 100, 40, step=10)
st.sidebar.markdown("---")
st.sidebar.caption("Sameer Sambyal · UID 25MCI10011")

# ---------------- Header ----------------
st.title("💬 NLP-Based Question Answering System")
st.caption("Retriever–Reader pipeline: TF-IDF retrieval + BERT (Hugging Face) extractive QA")

# ---------------- Knowledge base ----------------
st.subheader("1. Provide your knowledge base")
tab_upload, tab_paste, tab_sample = st.tabs(["📄 Upload files", "✍️ Paste text", "📚 Sample document"])
raw_text = ""

with tab_upload:
    files = st.file_uploader("Upload .txt or .pdf files", type=["txt", "pdf"], accept_multiple_files=True)
    if files:
        raw_text = "\n".join(read_uploaded(f) for f in files)

with tab_paste:
    pasted = st.text_area("Paste text here", height=200)
    if pasted.strip():
        raw_text = pasted

with tab_sample:
    if st.checkbox("Use the bundled sample document (Artificial Intelligence)"):
        with open(SAMPLE_PATH, encoding="utf-8") as f:
            raw_text = f.read()
        st.info("Sample loaded. Try: *Who coined the term artificial intelligence?*")

if not raw_text.strip():
    st.warning("Add a document above to begin.")
    st.stop()

# ---------------- Build index ----------------
reader = load_reader(model_name)
system = QASystem(reader, chunk_size=chunk_size, overlap=overlap)
n_chunks = system.index(raw_text)
c1, c2, c3 = st.columns(3)
c1.metric("Words in knowledge base", f"{len(tokenize(raw_text)):,}")
c2.metric("Chunks indexed", n_chunks)
c3.metric("Model", model_name.split("/")[-1])

# ---------------- Ask ----------------
st.subheader("2. Ask a question")
question = st.text_input("Your question", placeholder="e.g. What is machine learning?")

if st.button("Get Answer", type="primary") and question.strip():
    with st.spinner("Retrieving passages and reading with BERT..."):
        best, candidates = system.answer(question, top_k=top_k)

    if best is None:
        st.error("No answer found in the provided documents.")
    else:
        st.subheader("3. Answer")
        st.success(best.text)
        st.progress(min(max(best.confidence, 0.0), 1.0), text=f"Confidence: {best.confidence:.1%}")
        if best.confidence < 0.10:
            st.warning("Low confidence: the document may not contain a clear answer.")

        st.markdown("**Source passage**")
        st.markdown(highlight(best.context, best.start, best.end), unsafe_allow_html=True)

        with st.expander("🔍 All candidate answers (from retrieved chunks)"):
            for i, a in enumerate(candidates, 1):
                st.markdown(
                    f"**{i}. {a.text}** — confidence {a.confidence:.1%}, "
                    f"TF-IDF score {a.retrieval_score:.3f}, chunk #{a.chunk_id}"
                )
