"""
qa_engine.py
Retriever-Reader Question Answering engine.

Retriever : TF-IDF + cosine similarity   (classic NLP)
Reader    : BERT-family model (Hugging Face) for extractive QA (Deep Learning)
"""
import re
from dataclasses import dataclass
from typing import List

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

DEFAULT_MODEL = "distilbert-base-cased-distilled-squad"  # small, fast, CPU friendly
MODEL_OPTIONS = [
    "distilbert-base-cased-distilled-squad",
    "deepset/roberta-base-squad2",
    "bert-large-uncased-whole-word-masking-finetuned-squad",
]


# ----------------------------------------------------------------------------
# 1. Text preprocessing
# ----------------------------------------------------------------------------
def clean_text(text: str) -> str:
    """Normalize whitespace and remove control / odd characters (keeps case + punctuation
    because cased BERT models use them)."""
    text = text.replace("\r", " ")
    text = re.sub(r"[^\x09\x0A\x20-\x7E\u00A0-\uFFFF]", " ", text)  # control chars
    text = re.sub(r"-\n", "", text)          # words broken across lines (PDFs)
    text = re.sub(r"\s+", " ", text)         # collapse spaces/newlines
    return text.strip()


def tokenize(text: str) -> List[str]:
    """Simple word tokenizer (used for chunking and for display/statistics)."""
    return re.findall(r"\b\w+\b", text)


def chunk_text(text: str, chunk_size: int = 200, overlap: int = 40) -> List[str]:
    """Split text into overlapping word chunks so answers on a boundary aren't lost."""
    words = text.split()
    if not words:
        return []
    step = max(chunk_size - overlap, 1)
    chunks = []
    for start in range(0, len(words), step):
        piece = words[start:start + chunk_size]
        if piece:
            chunks.append(" ".join(piece))
        if start + chunk_size >= len(words):
            break
    return chunks


# ----------------------------------------------------------------------------
# 2. File loading
# ----------------------------------------------------------------------------
def read_pdf(file) -> str:
    from pypdf import PdfReader
    reader = PdfReader(file)
    return "\n".join((page.extract_text() or "") for page in reader.pages)


def read_uploaded(file) -> str:
    """file: Streamlit UploadedFile or any file-like object with .name"""
    name = file.name.lower()
    if name.endswith(".pdf"):
        return read_pdf(file)
    return file.read().decode("utf-8", errors="ignore")


# ----------------------------------------------------------------------------
# 3. Retriever (TF-IDF)
# ----------------------------------------------------------------------------
class TfidfRetriever:
    def __init__(self):
        self.vectorizer = TfidfVectorizer(
            lowercase=True,
            stop_words="english",
            ngram_range=(1, 2),
            sublinear_tf=True,
        )
        self.chunks: List[str] = []
        self.matrix = None

    def fit(self, chunks: List[str]):
        self.chunks = chunks
        self.matrix = self.vectorizer.fit_transform(chunks)
        return self

    def retrieve(self, question: str, top_k: int = 3):
        """Return list of (chunk_index, chunk_text, tfidf_score) sorted by score."""
        q_vec = self.vectorizer.transform([question])
        scores = cosine_similarity(q_vec, self.matrix).ravel()
        order = scores.argsort()[::-1][:top_k]
        return [(int(i), self.chunks[i], float(scores[i])) for i in order]


# ----------------------------------------------------------------------------
# 4. Reader (BERT / Transformer)
# ----------------------------------------------------------------------------
@dataclass
class Answer:
    text: str
    confidence: float
    context: str
    start: int
    end: int
    chunk_id: int
    retrieval_score: float


class QAReader:
    def __init__(self, model_name: str = DEFAULT_MODEL):
        from transformers import pipeline
        self.model_name = model_name
        self.pipe = pipeline("question-answering", model=model_name, tokenizer=model_name)

    def read(self, question: str, context: str):
        try:
            out = self.pipe(question=question, context=context,
                            handle_impossible_answer=False,
                            max_seq_len=384, doc_stride=128)
        except Exception:
            return None
        if not out or not out.get("answer", "").strip():
            return None
        return out


class QASystem:
    """Glue: documents -> chunks -> TF-IDF index -> BERT reader -> best answer."""

    def __init__(self, reader: QAReader, chunk_size: int = 200, overlap: int = 40):
        self.reader = reader
        self.chunk_size = chunk_size
        self.overlap = overlap
        self.retriever = TfidfRetriever()
        self.n_chunks = 0

    def index(self, raw_text: str) -> int:
        cleaned = clean_text(raw_text)
        chunks = chunk_text(cleaned, self.chunk_size, self.overlap)
        if not chunks:
            raise ValueError("No text found in the provided document(s).")
        self.retriever.fit(chunks)
        self.n_chunks = len(chunks)
        return self.n_chunks

    def answer(self, question: str, top_k: int = 3):
        """Returns (best_answer_or_None, all_candidates sorted by confidence)."""
        question = question.strip()
        candidates: List[Answer] = []
        for idx, chunk, r_score in self.retriever.retrieve(question, top_k):
            out = self.reader.read(question, chunk)
            if out is None:
                continue
            candidates.append(Answer(
                text=out["answer"].strip(),
                confidence=float(out["score"]),
                context=chunk,
                start=int(out["start"]),
                end=int(out["end"]),
                chunk_id=idx,
                retrieval_score=r_score,
            ))
        candidates.sort(key=lambda a: a.confidence, reverse=True)
        return (candidates[0] if candidates else None), candidates
