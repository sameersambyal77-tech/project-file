"""Quick offline test of preprocessing + TF-IDF retrieval (no model download needed)."""
from qa_engine import TfidfRetriever, chunk_text, clean_text

text = clean_text(open("sample_docs/sample.txt", encoding="utf-8").read())
chunks = chunk_text(text, chunk_size=60, overlap=10)
r = TfidfRetriever().fit(chunks)
for q, must in [("Who coined the term artificial intelligence?", "McCarthy"),
                ("What does TF-IDF stand for?", "Term Frequency"),
                ("When was BERT released?", "2018")]:
    top = r.retrieve(q, 2)
    ok = any(must in c for _, c, _ in top)
    print(("PASS" if ok else "FAIL"), "-", q)
    assert ok
