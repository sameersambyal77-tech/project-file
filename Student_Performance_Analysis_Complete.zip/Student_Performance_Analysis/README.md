# Student Performance Analysis
**Author:** Sameer Sambyal | **UID:** 25MCI10011
Analyzes students' marks, attendance, and CGPA to identify performance patterns.
**Stack:** Python, Pandas, Matplotlib, Power BI

## 1. Run the analysis
```bash
pip install pandas numpy matplotlib
python student_performance_analysis.py                 # sample data (300 students)
python student_performance_analysis.py your_data.csv   # your own data
```
Required columns: `StudentID, Name, Department, Semester, Attendance, Math, Physics, Programming, Databases, Networks, CGPA`
(edit the `SUBJECTS` list at the top of the script to match your subjects).

**Pipeline:** load -> clean (duplicates, missing values, range checks) -> feature engineering
(AvgMarks, Result, AttendanceBand, PerformanceCategory, AtRisk) -> analysis (describe, correlation,
regression, department / band / subject summaries) -> charts -> CSV export.

Outputs in `output/`: `students_clean.csv`, `subject_marks_long.csv`, `department_summary.csv`,
`attendance_band_summary.csv`, `subject_summary.csv`, `at_risk_students.csv`, and `charts/*.png`.

## 2. Build the Power BI dashboard
1. **Get Data -> Text/CSV**: load `students_clean.csv` (fact) and `subject_marks_long.csv`.
2. **Model view**: relate `students_clean[StudentID]` 1-to-many `subject_marks_long[StudentID]`.
3. Set `AttendanceBand` sort order (<60%, 60-75%, 75-90%, 90-100%) via Sort by Column, if needed.

### DAX measures
```DAX
Total Students   = DISTINCTCOUNT(students_clean[StudentID])
Avg CGPA         = AVERAGE(students_clean[CGPA])
Avg Attendance   = AVERAGE(students_clean[Attendance])
Avg Marks        = AVERAGE(students_clean[AvgMarks])
Pass Rate %      = DIVIDE(CALCULATE([Total Students], students_clean[Result] = "Pass"), [Total Students])
At-Risk Students = CALCULATE([Total Students], students_clean[AtRisk] = "Yes")
At-Risk %        = DIVIDE([At-Risk Students], [Total Students])
Subject Pass %   = DIVIDE(CALCULATE(COUNTROWS(subject_marks_long), subject_marks_long[Status] = "Pass"), COUNTROWS(subject_marks_long))
```

### Page layout
| Area | Visual | Fields |
|---|---|---|
| Top row | 5 Cards | Total Students, Avg CGPA, Avg Attendance, Pass Rate %, At-Risk % |
| Left | Scatter chart | X = Attendance, Y = AvgMarks, Legend = PerformanceCategory, Details = StudentID |
| Centre | Clustered column | Axis = Department, Values = Avg CGPA, Pass Rate % |
| Right | Column chart | Axis = AttendanceBand, Values = Avg Marks |
| Bottom-left | Bar chart | Axis = Subject (long table), Values = Subject Pass % |
| Bottom-right | Table | StudentID, Name, Department, Attendance, CGPA, FailedSubjects (filter AtRisk = Yes) |
| Slicers | Department, Semester, PerformanceCategory | |

Add conditional formatting (red < 5 CGPA) on the table and a drill-through page per student.

## 3. Key findings (sample data)
- Attendance and marks are positively correlated (r ≈ 0.52); +10% attendance ≈ +6 marks.
- Students under 60% attendance average ~41 marks vs ~66 for 90%+.
- Marks and CGPA are almost perfectly aligned (r ≈ 0.97).
- Department and subject differences are small; attendance is the strongest controllable driver.

## 4. Interactive Python dashboard (Streamlit)
```bash
pip install -r requirements.txt
streamlit run dashboard.py
```
Opens at http://localhost:8501 with sidebar filters (department, semester, attendance, category),
KPI cards, and four tabs: Overview, Attendance Impact, Subjects, At-Risk Students (with CSV download).
You can also upload your own CSV from the sidebar.
