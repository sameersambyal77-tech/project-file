"""
Student Performance Dashboard (Streamlit + Plotly)
Author : Sameer Sambyal | UID: 25MCI10011
Run    : streamlit run dashboard.py
"""
from pathlib import Path
import pandas as pd
import plotly.express as px
import streamlit as st
import student_performance_analysis as spa

SUBJECTS = spa.SUBJECTS
CLEAN_CSV = Path("output/students_clean.csv")

st.set_page_config(page_title="Student Performance Dashboard", page_icon="📊", layout="wide")


@st.cache_data
def load_data(uploaded=None):
    if uploaded is not None:
        return spa.add_features(spa.clean(pd.read_csv(uploaded)))
    if CLEAN_CSV.exists():
        return pd.read_csv(CLEAN_CSV)
    return spa.add_features(spa.clean(spa.generate_sample()))


# ------------------------------------------------------------------ sidebar
st.sidebar.title("🎛️ Filters")
upload = st.sidebar.file_uploader("Upload your own CSV (optional)", type="csv")
try:
    df = load_data(upload)
except Exception as e:
    st.sidebar.error(f"Could not read file: {e}")
    st.stop()

depts = st.sidebar.multiselect("Department", sorted(df["Department"].unique()),
                               default=sorted(df["Department"].unique()))
sems = st.sidebar.multiselect("Semester", sorted(df["Semester"].unique()),
                              default=sorted(df["Semester"].unique()))
att = st.sidebar.slider("Attendance %", 0, 100, (0, 100))
cats = st.sidebar.multiselect("Performance category", ["Poor", "Average", "Good", "Excellent"],
                              default=["Poor", "Average", "Good", "Excellent"])

f = df[df["Department"].isin(depts) & df["Semester"].isin(sems)
       & df["Attendance"].between(*att) & df["PerformanceCategory"].isin(cats)]

st.title("📊 Student Performance Dashboard")
st.caption("Marks, attendance and CGPA analysis  |  Sameer Sambyal (25MCI10011)")

if f.empty:
    st.warning("No students match the selected filters.")
    st.stop()

# --------------------------------------------------------------------- KPIs
k = st.columns(5)
k[0].metric("Students", len(f))
k[1].metric("Avg CGPA", f"{f['CGPA'].mean():.2f}")
k[2].metric("Avg Attendance", f"{f['Attendance'].mean():.1f}%")
k[3].metric("Pass Rate", f"{(f['Result'] == 'Pass').mean() * 100:.1f}%")
k[4].metric("At-Risk", f"{(f['AtRisk'] == 'Yes').mean() * 100:.1f}%")

tab1, tab2, tab3, tab4 = st.tabs(["Overview", "Attendance Impact", "Subjects", "At-Risk Students"])

# ----------------------------------------------------------------- overview
with tab1:
    c1, c2 = st.columns(2)
    c1.plotly_chart(px.histogram(f, x="CGPA", nbins=20, title="CGPA Distribution",
                                 color_discrete_sequence=["#4C72B0"]), width="stretch")
    d = f.groupby("Department").agg(AvgCGPA=("CGPA", "mean"), PassRate=("Result", lambda s: (s == "Pass").mean() * 100)).reset_index()
    c2.plotly_chart(px.bar(d, x="Department", y="AvgCGPA", color="PassRate", title="Average CGPA by Department (colour = pass rate %)",
                           color_continuous_scale="Viridis"), width="stretch")
    c3, c4 = st.columns(2)
    pc = f["PerformanceCategory"].value_counts().reindex(["Poor", "Average", "Good", "Excellent"]).fillna(0).reset_index()
    pc.columns = ["Category", "Students"]
    c3.plotly_chart(px.pie(pc, names="Category", values="Students", hole=.45, title="Performance Categories"), width="stretch")
    c4.plotly_chart(px.box(f, x="Department", y="AvgMarks", color="Department", title="Marks Spread by Department"), width="stretch")

# ------------------------------------------------------ attendance impact
with tab2:
    st.plotly_chart(px.scatter(f, x="Attendance", y="AvgMarks", color="CGPA", trendline="ols",
                               hover_data=["StudentID", "Department"], title="Attendance vs Average Marks",
                               color_continuous_scale="Viridis"), width="stretch")
    c1, c2 = st.columns(2)
    band = f.groupby("AttendanceBand", observed=True).agg(AvgMarks=("AvgMarks", "mean"), AvgCGPA=("CGPA", "mean")).reset_index()
    band["AttendanceBand"] = band["AttendanceBand"].astype(str)
    c1.plotly_chart(px.bar(band, x="AttendanceBand", y="AvgMarks", title="Avg Marks by Attendance Band",
                           color_discrete_sequence=["#C44E52"]), width="stretch")
    corr = f[["Attendance", "AvgMarks", "CGPA"] + SUBJECTS].corr().round(2)
    c2.plotly_chart(px.imshow(corr, text_auto=True, color_continuous_scale="RdBu_r", zmin=-1, zmax=1,
                              title="Correlation Heatmap"), width="stretch")

# ----------------------------------------------------------------- subjects
with tab3:
    s = pd.DataFrame({"Subject": SUBJECTS,
                      "AvgMarks": [f[x].mean() for x in SUBJECTS],
                      "PassRate": [(f[x] >= spa.PASS_MARK).mean() * 100 for x in SUBJECTS]}).round(2)
    c1, c2 = st.columns(2)
    c1.plotly_chart(px.bar(s, x="Subject", y="PassRate", title="Subject-wise Pass Rate %", range_y=[0, 100],
                           color_discrete_sequence=["#8172B2"]), width="stretch")
    c2.plotly_chart(px.bar(s, x="Subject", y="AvgMarks", title="Subject-wise Average Marks",
                           color_discrete_sequence=["#55A868"]), width="stretch")
    st.plotly_chart(px.box(f.melt(value_vars=SUBJECTS, var_name="Subject", value_name="Marks"),
                           x="Subject", y="Marks", color="Subject", title="Marks Distribution per Subject"),
                    width="stretch")

# ------------------------------------------------------------------ at-risk
with tab4:
    risk = f[f["AtRisk"] == "Yes"].sort_values("CGPA")
    st.write(f"**{len(risk)} at-risk students** (attendance < 65%, CGPA < 5, or 2+ failed subjects)")
    cols = ["StudentID", "Name", "Department", "Semester", "Attendance", "AvgMarks", "CGPA", "FailedSubjects"]
    st.dataframe(risk[cols], width="stretch", hide_index=True)
    st.download_button("⬇️ Download at-risk list (CSV)", risk[cols].to_csv(index=False), "at_risk_students.csv", "text/csv")

with st.expander("Show full filtered data"):
    st.dataframe(f, width="stretch")
