#!/bin/bash
pip install -r requirements.txt
python student_performance_analysis.py
streamlit run dashboard.py
