"""
Student Performance Analysis
Analyzes students' marks, attendance and CGPA to identify performance patterns.
Stack: Python, Pandas (analysis) -> CSV exports -> Power BI (dashboard)

Author : Sameer Sambyal
UID    : 25MCI10011

Usage:
    python student_performance_analysis.py                  # uses generated sample data
    python student_performance_analysis.py my_students.csv  # uses your own CSV
Required CSV columns: StudentID, Name, Department, Semester, Attendance,
                      Math, Physics, Programming, Databases, Networks, CGPA
"""
import sys
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

OUT = Path("output")
CHARTS = OUT / "charts"
CHARTS.mkdir(parents=True, exist_ok=True)
SUBJECTS = ["Math", "Physics", "Programming", "Databases", "Networks"]
PASS_MARK = 40


# ---------------------------------------------------------------- 1. LOAD
def generate_sample(n=300, seed=42):
    rng = np.random.default_rng(seed)
    dept = rng.choice(["CSE", "ECE", "Mechanical", "Civil", "IT"], n)
    ability = rng.normal(0, 1, n)
    attendance = np.clip(rng.normal(78, 12, n) + ability * 3, 40, 100)
    base = 55 + ability * 12 + (attendance - 75) * 0.35
    df = pd.DataFrame({
        "StudentID": [f"S{1000 + i}" for i in range(n)],
        "Name": [f"Student {i + 1}" for i in range(n)],
        "Department": dept,
        "Semester": rng.integers(1, 9, n),
        "Attendance": attendance.round(1),
    })
    for s in SUBJECTS:
        df[s] = np.clip(base + rng.normal(0, 9, n), 5, 100).round(0)
    df["CGPA"] = np.clip((df[SUBJECTS].mean(axis=1) / 10) + rng.normal(0, 0.3, n), 3, 10).round(2)
    # inject a few dirty values to demonstrate cleaning
    df.loc[rng.choice(n, 6, replace=False), "Attendance"] = np.nan
    df.loc[rng.choice(n, 4, replace=False), "Math"] = np.nan
    df = pd.concat([df, df.sample(3, random_state=1)], ignore_index=True)  # duplicates
    return df


def load():
    if len(sys.argv) > 1:
        return pd.read_csv(sys.argv[1])
    df = generate_sample()
    df.to_csv(OUT / "raw_students_sample.csv", index=False)
    return df


# --------------------------------------------------------------- 2. CLEAN
def clean(df):
    print(f"Raw rows: {len(df)}")
    df = df.drop_duplicates(subset="StudentID").copy()
    for col in SUBJECTS + ["Attendance", "CGPA"]:
        df[col] = pd.to_numeric(df[col], errors="coerce")
        df[col] = df[col].fillna(df.groupby("Department")[col].transform("median"))
    df[SUBJECTS] = df[SUBJECTS].clip(0, 100)
    df["Attendance"] = df["Attendance"].clip(0, 100)
    df["CGPA"] = df["CGPA"].clip(0, 10)
    print(f"Clean rows: {len(df)}")
    return df.reset_index(drop=True)


# ------------------------------------------------------------ 3. FEATURES
def add_features(df):
    df["TotalMarks"] = df[SUBJECTS].sum(axis=1)
    df["AvgMarks"] = df[SUBJECTS].mean(axis=1).round(2)
    df["FailedSubjects"] = (df[SUBJECTS] < PASS_MARK).sum(axis=1)
    df["Result"] = np.where(df["FailedSubjects"] == 0, "Pass", "Fail")
    df["AttendanceBand"] = pd.cut(df["Attendance"], [0, 60, 75, 90, 100],
                                  labels=["<60%", "60-75%", "75-90%", "90-100%"], include_lowest=True)
    df["PerformanceCategory"] = pd.cut(df["CGPA"], [0, 5, 6.5, 8, 10],
                                       labels=["Poor", "Average", "Good", "Excellent"], include_lowest=True)
    # at-risk: attendance below 65%, CGPA below 5, or 2+ failed subjects
    df["AtRisk"] = ((df["Attendance"] < 65) | (df["CGPA"] < 5.0) | (df["FailedSubjects"] >= 2))
    df["AtRisk"] = df["AtRisk"].map({True: "Yes", False: "No"})
    return df


# ------------------------------------------------------------ 4. ANALYSIS
def analyze(df):
    print("\n=== Descriptive statistics ===")
    print(df[SUBJECTS + ["Attendance", "AvgMarks", "CGPA"]].describe().round(2))

    corr = df[["Attendance", "AvgMarks", "CGPA"] + SUBJECTS].corr().round(3)
    print("\n=== Correlation matrix ===\n", corr)

    slope, intercept = np.polyfit(df["Attendance"], df["AvgMarks"], 1)
    print(f"\nAttendance -> AvgMarks trend: each +10% attendance ≈ {slope * 10:.2f} marks")

    dept = df.groupby("Department").agg(
        Students=("StudentID", "count"), AvgMarks=("AvgMarks", "mean"),
        AvgAttendance=("Attendance", "mean"), AvgCGPA=("CGPA", "mean"),
        PassRate=("Result", lambda s: (s == "Pass").mean() * 100),
        AtRiskCount=("AtRisk", lambda s: (s == "Yes").sum()),
    ).round(2).reset_index()
    print("\n=== Department summary ===\n", dept)

    band = df.groupby("AttendanceBand", observed=True).agg(
        Students=("StudentID", "count"), AvgMarks=("AvgMarks", "mean"),
        AvgCGPA=("CGPA", "mean")).round(2).reset_index()
    print("\n=== Attendance band vs performance ===\n", band)

    subj = pd.DataFrame({
        "Subject": SUBJECTS,
        "AvgMarks": [df[s].mean() for s in SUBJECTS],
        "PassRate": [(df[s] >= PASS_MARK).mean() * 100 for s in SUBJECTS],
        "StdDev": [df[s].std() for s in SUBJECTS],
    }).round(2)
    print("\n=== Subject analysis ===\n", subj)

    print("\nTop 5 students:\n", df.nlargest(5, "CGPA")[["StudentID", "Department", "CGPA", "Attendance"]])
    print("\nAt-risk students:", (df["AtRisk"] == "Yes").sum(), f"of {len(df)}")
    return dept, band, subj, corr, (slope, intercept)


# -------------------------------------------------------------- 5. CHARTS
def charts(df, dept, band, subj, corr, fit):
    plt.style.use("seaborn-v0_8-whitegrid")

    fig, ax = plt.subplots(figsize=(7, 5))
    ax.scatter(df["Attendance"], df["AvgMarks"], c=df["CGPA"], cmap="viridis", alpha=.75)
    xs = np.linspace(df["Attendance"].min(), 100, 50)
    ax.plot(xs, fit[0] * xs + fit[1], "r--", label="Trend")
    ax.set(xlabel="Attendance %", ylabel="Average marks", title="Attendance vs Marks (colour = CGPA)")
    ax.legend(); fig.tight_layout(); fig.savefig(CHARTS / "attendance_vs_marks.png", dpi=150); plt.close()

    fig, ax = plt.subplots(figsize=(7, 5))
    ax.hist(df["CGPA"], bins=20, color="#4C72B0", edgecolor="white")
    ax.set(xlabel="CGPA", ylabel="Students", title="CGPA Distribution")
    fig.tight_layout(); fig.savefig(CHARTS / "cgpa_distribution.png", dpi=150); plt.close()

    fig, ax = plt.subplots(figsize=(7, 5))
    ax.bar(dept["Department"], dept["AvgCGPA"], color="#55A868")
    ax.set(ylabel="Average CGPA", title="Average CGPA by Department")
    fig.tight_layout(); fig.savefig(CHARTS / "dept_cgpa.png", dpi=150); plt.close()

    fig, ax = plt.subplots(figsize=(7, 5))
    ax.bar(band["AttendanceBand"].astype(str), band["AvgMarks"], color="#C44E52")
    ax.set(xlabel="Attendance band", ylabel="Average marks", title="Marks by Attendance Band")
    fig.tight_layout(); fig.savefig(CHARTS / "attendance_band_marks.png", dpi=150); plt.close()

    fig, ax = plt.subplots(figsize=(7, 5))
    ax.bar(subj["Subject"], subj["PassRate"], color="#8172B2")
    ax.set(ylabel="Pass rate %", title="Subject-wise Pass Rate", ylim=(0, 100))
    fig.tight_layout(); fig.savefig(CHARTS / "subject_pass_rate.png", dpi=150); plt.close()

    fig, ax = plt.subplots(figsize=(7, 6))
    im = ax.imshow(corr, cmap="coolwarm", vmin=-1, vmax=1)
    ax.set_xticks(range(len(corr))); ax.set_xticklabels(corr.columns, rotation=45, ha="right")
    ax.set_yticks(range(len(corr))); ax.set_yticklabels(corr.columns)
    fig.colorbar(im); ax.set_title("Correlation Heatmap")
    fig.tight_layout(); fig.savefig(CHARTS / "correlation_heatmap.png", dpi=150); plt.close()


# --------------------------------------------------------- 6. POWER BI EXPORT
def export(df, dept, band, subj):
    df.to_csv(OUT / "students_clean.csv", index=False)                       # fact table
    long = df.melt(id_vars=["StudentID", "Department", "Semester"], value_vars=SUBJECTS,
                   var_name="Subject", value_name="Marks")
    long["Status"] = np.where(long["Marks"] >= PASS_MARK, "Pass", "Fail")
    long.to_csv(OUT / "subject_marks_long.csv", index=False)                 # for subject visuals
    dept.to_csv(OUT / "department_summary.csv", index=False)
    band.to_csv(OUT / "attendance_band_summary.csv", index=False)
    subj.to_csv(OUT / "subject_summary.csv", index=False)
    df[df["AtRisk"] == "Yes"].sort_values("CGPA").to_csv(OUT / "at_risk_students.csv", index=False)
    print(f"\nExports written to {OUT.resolve()}")


if __name__ == "__main__":
    raw = load()
    data = add_features(clean(raw))
    dept_s, band_s, subj_s, corr_m, fit_ = analyze(data)
    charts(data, dept_s, band_s, subj_s, corr_m, fit_)
    export(data, dept_s, band_s, subj_s)
